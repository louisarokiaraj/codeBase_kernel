/******************************************************************************/
/* Important Spring 2015 CSCI 402 usage information:                          */
/*                                                                            */
/* This fils is part of CSCI 402 kernel programming assignments at USC.       */
/* Please understand that you are NOT permitted to distribute or publically   */
/*         display a copy of this file (or ANY PART of it) for any reason.    */
/* If anyone (including your prospective employer) asks you to post the code, */
/*         you must inform them that you do NOT have permissions to do so.    */
/* You are also NOT permitted to remove or alter this comment block.          */
/* If this comment block is removed or altered in a submitted file, 20 points */
/*         will be deducted.                                                  */
/******************************************************************************/

#include "kernel.h"
#include "globals.h"
#include "types.h"
#include "errno.h"

#include "util/string.h"
#include "util/printf.h"
#include "util/debug.h"

#include "fs/dirent.h"
#include "fs/fcntl.h"
#include "fs/stat.h"
#include "fs/vfs.h"
#include "fs/vnode.h"

/* This takes a base 'dir', a 'name', its 'len', and a result vnode.
 * Most of the work should be done by the vnode's implementation
 * specific lookup() function, but you may want to special case
 * "." and/or ".." here depnding on your implementation.
 *
 * If dir has no lookup(), return -ENOTDIR.
 *
 * Note: returns with the vnode refcount on *result incremented.
 */
int
lookup(vnode_t *dir, const char *name, size_t len, vnode_t **result)
{
        /*NOT_YET_IMPLEMENTED("VFS: lookup");*/
        KASSERT(NULL != dir);
        KASSERT(NULL != name);
        KASSERT(NULL != result);
        
        int retVal;
        if(dir->vn_ops->lookup==NULL){
        	return -ENOTDIR;
        
        }
        if(len == 0)
        {
        	*result = vget(dir->vn_fs, dir->vn_vno);
       		 return 0;
        }
        if(strlen(name)>NAME_LEN){
			
		return ENAMETOOLONG;
	}
        
        if(!strcmp(name,".")){
        	vref(dir);
        	*result=dir;
        }
        
       /* else if(!strcmp(name,"..")){
        
        	
        	
        }*/
        
        
        else{
        
        	if((retVal=dir->vn_ops->lookup(dir, name,len,result))!=0){
        		return retVal;
        		
        	}
        }
       
       /* dbg(DBG_TEMP,"lookup-%s %ld %x\n",name,(long)((*result)->vn_vno),  (*result)->vn_refcount);*/
        
        return 0;
}


/* When successful this function returns data in the following "out"-arguments:
 *  o res_vnode: the vnode of the parent directory of "name"
 *  o name: the `basename' (the element of the pathname)
 *  o namelen: the length of the basename
 *
 * For example: dir_namev("/s5fs/bin/ls", &namelen, &name, NULL,
 * &res_vnode) would put 2 in namelen, "ls" in name, and a pointer to the
 * vnode corresponding to "/s5fs/bin" in res_vnode.
 *
 * The "base" argument defines where we start resolving the path from:
 * A base value of NULL means to use the process's current working directory,
 * curproc->p_cwd.  If pathname[0] == '/', ignore base and start with
 * vfs_root_vn.  dir_namev() should call lookup() to take care of resolving each
 * piece of the pathname.
 *
 * Note: A successful call to this causes vnode refcount on *res_vnode to
 * be incremented.
 */
int
dir_namev(const char *pathname, size_t *namelen, const char **name,
          vnode_t *base, vnode_t **res_vnode)
{
       /* NOT_YET_IMPLEMENTED("VFS: dir_namev");*/
       
       /*   *//*   *//*   *//*   *//*   *//*   *//*   */
       /*check !!!!! vref and vput at req places!!!!!!!!!*/
       /* *//*   *//*   *//*   *//*   *//*   *//*   *//*   */
       
       
       KASSERT(NULL != pathname);
       KASSERT(NULL != namelen);
       KASSERT(NULL != name);
       KASSERT(NULL != res_vnode);
      

      /*  dbg(DBG_TEMP,"dir_namev-%s\n",pathname);*/
       
       
       
       
       
       vnode_t *start_vnode;
       vnode_t *result;
       int retVal=0;
       if(!strcmp(pathname,"/")){
       		*res_vnode=vfs_root_vn;
       		vref(vfs_root_vn);
       		*name="";
       		*namelen=0;
       		return 0;
       
       }
       if(pathname[0]=='/'){
       		start_vnode=vfs_root_vn;
       		vref(start_vnode);
       }
       else if(base==NULL){
       
       		start_vnode=curproc->p_cwd;
       		vref(start_vnode);	
       }
       else{
       
       		start_vnode=base;
       		vref(start_vnode);
       }
      
	char delim[2]="/";
        int delimInt ='/';
	char *dir_name;
	char *file_name;
	int tempLength=0;
	
	/*char tempString[strlen(pathname)+1];*/
	/*tempString[strlen(pathname)]='\0';*/
	char tempString[1000]; /*think of other way*/
	memset(tempString,'\0',sizeof(tempString));
	strcpy(tempString,pathname);
	
	/*handle slashes at end*/
	int endSlash=0,i=0;
	for(i=strlen(tempString);i>0;i--){
		if(tempString[i-1]=='/'){
			tempString[i-1]='\0';
			endSlash++;
		}
		else{
			break;
		}
	
	}
	
	file_name= strrchr(tempString,delimInt);
	
	if(file_name==NULL){
	
		file_name=tempString;
	}
	else{
		file_name++;
	}
	tempLength=strlen(file_name);


	dir_name=strtok(tempString,delim);

	while((dir_name!=NULL) && (dir_name!=file_name)){

		if(strlen(dir_name)>NAME_LEN){
			vput(start_vnode);
			return -ENAMETOOLONG;
		}
		
		if((retVal=lookup(start_vnode, dir_name, strlen(dir_name), &result))!=0){
			vput(start_vnode);
			
			return retVal;
		
		}
		if(!(S_ISDIR(result->vn_mode))){
			vput(result);/*test*/
			vput(start_vnode);
			return -ENOTDIR;
		
		}
		
		
		vput(start_vnode);/*dec ref count of parent dir*/
		start_vnode=result;/* moving through the path*/
	
		dir_name=strtok(NULL,delim);


	}
      
      KASSERT(NULL != start_vnode);
     *name=&pathname[strlen(pathname)-tempLength-endSlash]; /*check--------> find index*/
     /**(name[tempLength])='\0';*/
     
     *res_vnode=start_vnode;
       *namelen=tempLength;
       
       
       
        return 0;
}

/* This returns in res_vnode the vnode requested by the other parameters.
 * It makes use of dir_namev and lookup to find the specified vnode (if it
 * exists).  flag is right out of the parameters to open(2); see
 * <weenix/fcntl.h>.  If the O_CREAT flag is specified, and the file does
 * not exist call create() in the parent directory vnode.
 *
 * Note: Increments vnode refcount on *res_vnode.
 */
int
open_namev(const char *pathname, int flag, vnode_t **res_vnode, vnode_t *base)
{
        /*NOT_YET_IMPLEMENTED("VFS: open_namev");*/
        /*dont know the return values of create and lookup in vnode sp func, use vput , vref appropriately*/
        vnode_t *dir_vnode;
        const char *name;
        size_t namelen;
        int rval;
        /* dbg(DBG_TEMP,"opennamev-%s\n",pathname);*/
        /*get the directory vnode*/
        if((rval=dir_namev(pathname,&namelen,&name,base, &dir_vnode))!=0){
      		
        	return rval;
        }
        
        
        
        if((rval=lookup(dir_vnode, name,namelen,res_vnode))!=0){
        
        	/*file is not present , creating a new one*/
        	if((flag & O_CREAT) == O_CREAT){
        		KASSERT(NULL !=dir_vnode->vn_ops->create);
        	
        		if((rval=dir_vnode->vn_ops->create(dir_vnode,name,namelen,res_vnode))<0){
        		
        			vput(dir_vnode);
        			return rval;
        		
        		}
        		
        
       		}
       		else{
       			vput(dir_vnode);
       			return rval;
       		}
        
        }
        
        
        
       
        
        /*vput(*res_vnode); */
        vput(dir_vnode);/*ref not needed, so decreasing*/
        return 0;
}

#ifdef __GETCWD__
/* Finds the name of 'entry' in the directory 'dir'. The name is writen
 * to the given buffer. On success 0 is returned. If 'dir' does not
 * contain 'entry' then -ENOENT is returned. If the given buffer cannot
 * hold the result then it is filled with as many characters as possible
 * and a null terminator, -ERANGE is returned.
 *
 * Files can be uniquely identified within a file system by their
 * inode numbers. */
int
lookup_name(vnode_t *dir, vnode_t *entry, char *buf, size_t size)
{
        NOT_YET_IMPLEMENTED("GETCWD: lookup_name");
        return -ENOENT;
}


/* Used to find the absolute path of the directory 'dir'. Since
 * directories cannot have more than one link there is always
 * a unique solution. The path is writen to the given buffer.
 * On success 0 is returned. On error this function returns a
 * negative error code. See the man page for getcwd(3) for
 * possible errors. Even if an error code is returned the buffer
 * will be filled with a valid string which has some partial
 * information about the wanted path. */
ssize_t
lookup_dirpath(vnode_t *dir, char *buf, size_t osize)
{
        NOT_YET_IMPLEMENTED("GETCWD: lookup_dirpath");

        return -ENOENT;
}
#endif /* __GETCWD__ */
