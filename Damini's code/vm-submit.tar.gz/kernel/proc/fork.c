/******************************************************************************/
/* Important Spring 2015 CSCI 402 usage information:                          */
/*                                                                            */
/* This fils is part of CSCI 402 kernel programming assignments at USC.       */
/* Please understand that you are NOT permitted to distribute or publically   */
/*         display a copy of this file (or ANY PART of it) for any reason.    */
/* If anyone (including your prospective employer) asks you to post the code, */
/*         you must inform them that you do NOT have permissions to do so.    */
/* You are also NOT permitted to remove or alter this comment block.          */
/* If this comment block is removed or altered in a submitted file, 20 points */
/*         will be deducted.                                                  */
/******************************************************************************/

#include "types.h"
#include "globals.h"
#include "errno.h"

#include "util/debug.h"
#include "util/string.h"

#include "proc/proc.h"
#include "proc/kthread.h"

#include "mm/mm.h"
#include "mm/mman.h"
#include "mm/page.h"
#include "mm/pframe.h"
#include "mm/mmobj.h"
#include "mm/pagetable.h"
#include "mm/tlb.h"

#include "fs/file.h"
#include "fs/vnode.h"

#include "vm/shadow.h"
#include "vm/vmmap.h"

#include "api/exec.h"

#include "main/interrupt.h"

/* Pushes the appropriate things onto the kernel stack of a newly forked thread
 * so that it can begin execution in userland_entry.
 * regs: registers the new thread should have on execution
 * kstack: location of the new thread's kernel stack
 * Returns the new stack pointer on success. */
static uint32_t
fork_setup_stack(const regs_t *regs, void *kstack)
{
        /* Pointer argument and dummy return address, and userland dummy return
         * address */
        uint32_t esp = ((uint32_t) kstack) + DEFAULT_STACK_SIZE - (sizeof(regs_t) + 12);
        *(void **)(esp + 4) = (void *)(esp + 8); /* Set the argument to point to location of struct on stack */
        memcpy((void *)(esp + 8), regs, sizeof(regs_t)); /* Copy over struct */
        return esp;
}


/*
 * The implementation of fork(2). Once this works,
 * you're practically home free. This is what the
 * entirety of Weenix has been leading up to.
 * Go forth and conquer.
 */
int
do_fork(struct regs *regs)
{

       	KASSERT(regs != NULL);
        dbg(DBG_PRINT, "(GRADING3A 7.a)\n");
	KASSERT(curproc != NULL);
        dbg(DBG_PRINT, "(GRADING3A 7.a)\n");
	KASSERT(curproc->p_state == PROC_RUNNING);
        dbg(DBG_PRINT, "(GRADING3A 7.a)\n");

         vmmap_t* new = NULL;
         proc_t *newproc = proc_create("forkch");
        /* if(newproc==NULL){
		dbg(DBG_PRINT, "(Untested Code Path)\n");
         	return -1;
         }*/
	KASSERT(newproc->p_state == PROC_RUNNING);
        dbg(DBG_PRINT, "(GRADING3A 7.a)\n");
	
        
         if((new=vmmap_clone(curproc->p_vmmap))!=NULL){
		dbg(DBG_PRINT, "(GRADING3D 2)\n");
         	newproc->p_vmmap = new;
         	new->vmm_proc = newproc;
         }
	/*else{
		dbg(DBG_PRINT, "(Untested Code Path)\n");
         	proc_kill(newproc,-1);
         	return -1;
         }*/
         dbg(DBG_PRINT, "(GRADING3D 2)\n");
         vmarea_t *area_iter=NULL,*parent_area=NULL;
         mmobj_t *shadow_1=NULL,*shadow_parent=NULL;
         
         list_iterate_begin(&(new->vmm_list), area_iter, vmarea_t, vma_plink){
         	
		dbg(DBG_PRINT, "(GRADING3D 2)\n");
         	parent_area = vmmap_lookup(curproc->p_vmmap,area_iter->vma_start);
         	KASSERT(parent_area!=NULL);/*remove*/
		
         	if(area_iter->vma_flags & MAP_PRIVATE)
		{
			dbg(DBG_PRINT, "(GRADING3D 2)\n");
         	  	parent_area->vma_obj->mmo_ops->ref(parent_area->vma_obj);
                
               	  	/*if((shadow_1 = shadow_create())==NULL){
				dbg(DBG_PRINT, "(Untested Code Path)\n");
         			proc_kill(newproc,-1);
         			return -1;
         	  	}*/
			shadow_1 = shadow_create();
               
                
                  	shadow_1->mmo_un.mmo_bottom_obj = parent_area->vma_obj->mmo_un.mmo_bottom_obj;
                  	shadow_1->mmo_shadowed = parent_area->vma_obj;
                
                  	/*if((shadow_parent= shadow_create())==NULL){
				dbg(DBG_PRINT, "(Untested Code Path)\n");
         			proc_kill(newproc,-1);
         			return -1;
                   	}*/
			shadow_parent= shadow_create();
			dbg(DBG_PRINT, "(GRADING3D 2)\n");
         		shadow_parent->mmo_shadowed=shadow_1->mmo_shadowed;
                	shadow_parent->mmo_un.mmo_bottom_obj = parent_area->vma_obj->mmo_un.mmo_bottom_obj;
               		parent_area->vma_obj = shadow_parent;
               		area_iter->vma_obj = shadow_1;
        
               		list_insert_head(&(shadow_parent->mmo_un.mmo_bottom_obj->mmo_un.mmo_vmas),&area_iter->vma_olink);
                
         	}
         	else if(area_iter->vma_flags & MAP_SHARED) 
		{
         		dbg(DBG_PRINT, "(GRADING3D 2)\n");
         		area_iter->vma_obj=parent_area->vma_obj; 
         		parent_area->vma_obj->mmo_ops->ref(parent_area->vma_obj);
         		list_insert_head(&(parent_area->vma_obj->mmo_un.mmo_vmas),&area_iter->vma_olink);
         		
         	}
         	/*else
		{
				dbg(DBG_PRINT, "(Untested Code Path)\n");
         			proc_kill(newproc,-1);
         			return -1;
         		
         	}*/
         	dbg(DBG_PRINT, "(GRADING3D 2)\n");
         }list_iterate_end();

       dbg(DBG_PRINT, "(GRADING3D 2)\n");
       
       
       KASSERT(newproc->p_pagedir != NULL);
        dbg(DBG_PRINT, "(GRADING3A 7.a)\n");
       
        pt_unmap_range(newproc->p_pagedir,USER_MEM_LOW,USER_MEM_HIGH);
	pt_unmap_range(curproc->p_pagedir,USER_MEM_LOW,USER_MEM_HIGH);
	
	 
       
        kthread_t *child_thr= kthread_clone(curthr);

      /*  if(child_thr == NULL)
	{
	dbg(DBG_PRINT, "(Untested Code Path)\n");
       
           return -1;
   	}*/
	
   	KASSERT(child_thr->kt_kstack != NULL);
        dbg(DBG_PRINT, "(GRADING3A 7.a)\n");
    
 
    
     regs->r_eax = 0;
        child_thr->kt_ctx.c_pdptr= newproc->p_pagedir;
        child_thr->kt_ctx.c_eip= (uint32_t) userland_entry;
        child_thr->kt_ctx.c_esp= fork_setup_stack(regs, (void *)child_thr->kt_ctx.c_kstack);
        child_thr->kt_ctx.c_kstack=(uintptr_t) child_thr->kt_kstack;
        child_thr->kt_ctx.c_kstacksz=DEFAULT_STACK_SIZE;
      child_thr->kt_state=KT_RUN;
   list_insert_tail(&(newproc->p_threads),&(child_thr->kt_plink));/*!!!!!!!!!!!!!*/
    child_thr->kt_proc = newproc;/*!!!!!!!!!!!*/
     int i=0;
        for(i=0;i<NFILES;i++){
        	if(newproc->p_files[i])
		{
			dbg(DBG_PRINT, "(GRADING3D 2)\n");
        		newproc->p_files[i]=curproc->p_files[i];
        	}
		dbg(DBG_PRINT, "(GRADING3D 2)\n");
        }

    
   	 newproc->p_cwd=curproc->p_cwd;
        /*vref(curproc->p_cwd);*/
        
        newproc->p_brk=curproc->p_brk;
        newproc->p_start_brk = curproc->p_start_brk;
        regs->r_eax = newproc->p_pid;
        sched_make_runnable(child_thr);
        
        tlb_flush_all();
	dbg(DBG_PRINT, "(GRADING3D 2)\n");
        return newproc->p_pid;
    
  

         
}
