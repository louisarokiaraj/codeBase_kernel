/******************************************************************************/
/* Important Spring 2015 CSCI 402 usage information:                          */
/*                                                                            */
/* This fils is part of CSCI 402 kernel programming assignments at USC.       */
/* Please understand that you are NOT permitted to distribute or publically   */
/*         display a copy of this file (or ANY PART of it) for any reason.    */
/* If anyone (including your prospective employer) asks you to post the code, */
/*         you must inform them that you do NOT have permissions to do so.    */
/* You are also NOT permitted to remove or alter this comment block.          */
/* If this comment block is removed or altered in a submitted file, 20 points */
/*         will be deducted.                                                  */
/******************************************************************************/

#include "globals.h"
#include "errno.h"
#include "types.h"

#include "mm/mm.h"
#include "mm/tlb.h"
#include "mm/mman.h"
#include "mm/page.h"

#include "proc/proc.h"

#include "util/string.h"
#include "util/debug.h"

#include "fs/vnode.h"
#include "fs/vfs.h"
#include "fs/file.h"

#include "vm/vmmap.h"
#include "vm/mmap.h"

/*
 * This function implements the mmap(2) syscall, but only
 * supports the MAP_SHARED, MAP_PRIVATE, MAP_FIXED, and
 * MAP_ANON flags.
 *
 * Add a mapping to the current process's address space.
 * You need to do some error checking; see the ERRORS section
 * of the manpage for the problems you should anticipate.
 * After error checking most of the work of this function is
 * done by vmmap_map(), but remember to clear the TLB.
 */
int
do_mmap(void *addr, size_t len, int prot, int flags,
        int fd, off_t off, void **ret)
{
	dbg(DBG_PRINT, "(GRADING3D 2)\n");
     file_t* file=NULL;
     vnode_t *file_vnode=NULL;
     
 	if (addr != NULL) {
		
		
		if(((flags & MAP_FIXED)==MAP_FIXED) && (!PAGE_ALIGNED(addr))) {
       			dbg(DBG_PRINT, "(GRADING3D 2)\n");
       			return -EINVAL;
       		}
       		
       		 /*if((uintptr_t)addr>= USER_MEM_HIGH || (uintptr_t)addr < USER_MEM_LOW  ){
       			dbg(DBG_PRINT, "(Untested Code Path)\n");
       			return -EINVAL;
       		
        	}
       		if(len<=0||(uintptr_t)addr+len >= USER_MEM_HIGH || (uintptr_t)addr+len < USER_MEM_LOW  ){
       			dbg(DBG_PRINT, "(Untested Code Path)\n");
       			return -EINVAL;
       		
       		}*/
		dbg(DBG_PRINT, "(GRADING3D 2)\n");

	} 
	if ((addr == NULL) && (flags & MAP_FIXED)) {
		dbg(DBG_PRINT, "(GRADING3D 2)\n");	
		return -EINVAL;	
	}

	if ((addr == NULL) && (len<=0 || len > USER_MEM_HIGH - USER_MEM_LOW + 1)) {
		dbg(DBG_PRINT, "(GRADING3D 2)\n");	
		return -EINVAL;
	}
		


	if ((!(flags & MAP_PRIVATE) && !(flags & MAP_SHARED))||((flags & MAP_PRIVATE) && (flags & MAP_SHARED))) {
		dbg(DBG_PRINT, "(GRADING3D 2)\n");
		return -EINVAL;
	}
      
       
       
	if (!(flags & MAP_ANON)) {
	
		 if((fd>NFILES||fd<0)||((file=fget(fd))==NULL)){
       		 		dbg(DBG_PRINT, "(GRADING3D 2)\n");
       		 		return -EBADF;
       		 
       		 }
		dbg(DBG_PRINT, "(GRADING3D 2)\n");
	}
	
	if(file){
		if (!PAGE_ALIGNED(off)) {
			dbg(DBG_PRINT, "(GRADING3D 2)\n");
			fput(file);
			return -EINVAL;
		}

		/*if ((flags & MAP_PRIVATE) && !(file->f_mode & FMODE_READ)) {
			fput(file);
			return -EACCES;
		} */
		
		 if(((prot & PROT_WRITE)  && (flags & MAP_SHARED)&&!((file->f_mode & FMODE_WRITE )== FMODE_WRITE) )){
			dbg(DBG_PRINT, "(GRADING3D 2)\n");
       		 	fput(file);
       		 	return -EACCES;
       		 }
		
		 /*if ((prot & PROT_WRITE ) && (file->f_mode & FMODE_APPEND)) { 
			dbg(DBG_PRINT, "(Untested Code Path)\n");
			fput(file);
			return -EACCES;
		}*/
		dbg(DBG_PRINT, "(GRADING3D 2)\n");
		file_vnode = file->f_vnode;
	} 
	/***********************************/
       dbg(DBG_PRINT, "(GRADING3D 2)\n");
       vmarea_t *new;
       uint32_t lopage = 0;
       lopage = ADDR_TO_PN(addr);
       
       uint32_t npages = len/PAGE_SIZE;
       if(len%PAGE_SIZE!=0)
	{
		dbg(DBG_PRINT, "(GRADING3D 2)\n");
       		npages++;
       }
       int retVal=0;
       if((retVal=vmmap_map(curproc->p_vmmap,file_vnode, lopage,npages,prot,  flags, off, VMMAP_DIR_HILO, &new))<0){/*chk the val of dir*/
       		
       		/* if(file){
			dbg(DBG_PRINT, "(Untested Code Path)\n");
       		 	fput(file);
       		 }*/
		dbg(DBG_PRINT, "(GRADING3D 3)\n");
       		return retVal;
       }
      
       
       *ret = PN_TO_ADDR(new->vma_start);
       
        /*flush tlb*/
       tlb_flush_all();
       	
        if(file){
		dbg(DBG_PRINT, "(GRADING3D 2)\n");
       		 fput(file);
       	}
	dbg(DBG_PRINT, "(GRADING3D 2)\n");
	KASSERT(NULL != curproc->p_pagedir);
        dbg(DBG_PRINT, "(GRADING3A 2.a)\n");	 
       	return 0;       
 
}


/*
 * This function implements the munmap(2) syscall.
 *
 * As with do_mmap() it should perform the required error checking,
 * before calling upon vmmap_remove() to do most of the work.
 * Remember to clear the TLB.
 */
int
do_munmap(void *addr, size_t len)
{
      /* if(len <=0 || len > 0xc0000000)
			return -EINVAL;*/
	dbg(DBG_PRINT, "(GRADING3D 2)\n");
	uint32_t lopage=(uintptr_t)addr/PAGE_SIZE;
        uint32_t npages = len/PAGE_SIZE;
        if(len%PAGE_SIZE!=0)
	{
		dbg(DBG_PRINT, "(GRADING3D 2)\n");
       		npages++;
	}	
        if(len <=0 || len >= USER_MEM_HIGH){
		dbg(DBG_PRINT, "(GRADING3D 2)\n");
		return -EINVAL;
        }
	/****/
	
	 if((uintptr_t)addr>= USER_MEM_HIGH || (uintptr_t)addr < USER_MEM_LOW  ){
       			dbg(DBG_PRINT, "(GRADING3D 2)\n");
       			return -EINVAL;
       		
       	}
        
       	
	/*if (!PAGE_ALIGNED(addr)) {
			dbg(DBG_PRINT, "(Untested Code Path)\n");
			return -EINVAL;
	}*/
	
	
		
	 int retVal=0;
       
       /* if((retVal=vmmap_remove(curproc->p_vmmap,lopage ,npages))<0){
        	dbg(DBG_PRINT, "(Untested Code Path)\n");
        	return retVal;
        }*/
	vmmap_remove(curproc->p_vmmap,lopage ,npages);
        tlb_flush_all();
	dbg(DBG_PRINT, "(GRADING3D 2)\n");
	KASSERT(NULL != curproc->p_pagedir);
        dbg(DBG_PRINT, "(GRADING3A 2.b)\n");
        return 0;
}

