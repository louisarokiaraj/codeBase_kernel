/******************************************************************************/
/* Important Spring 2015 CSCI 402 usage information:                          */
/*                                                                            */
/* This fils is part of CSCI 402 kernel programming assignments at USC.       */
/* Please understand that you are NOT permitted to distribute or publically   */
/*         display a copy of this file (or ANY PART of it) for any reason.    */
/* If anyone (including your prospective employer) asks you to post the code, */
/*         you must inform them that you do NOT have permissions to do so.    */
/* You are also NOT permitted to remove or alter this comment block.          */
/* If this comment block is removed or altered in a submitted file, 20 points */
/*         will be deducted.                                                  */
/******************************************************************************/

#include "globals.h"
#include "errno.h"

#include "util/string.h"
#include "util/debug.h"

#include "mm/mmobj.h"
#include "mm/pframe.h"
#include "mm/mm.h"
#include "mm/page.h"
#include "mm/slab.h"
#include "mm/tlb.h"

#include "vm/vmmap.h"
#include "vm/shadow.h"
#include "vm/shadowd.h"

#define SHADOW_SINGLETON_THRESHOLD 5

int shadow_count = 0; /* for debugging/verification purposes */
#ifdef __SHADOWD__
/*
 * number of shadow objects with a single parent, that is another shadow
 * object in the shadow objects tree(singletons)
 */
static int shadow_singleton_count = 0;
#endif

static slab_allocator_t *shadow_allocator;

static void shadow_ref(mmobj_t *o);
static void shadow_put(mmobj_t *o);
static int  shadow_lookuppage(mmobj_t *o, uint32_t pagenum, int forwrite, pframe_t **pf);
static int  shadow_fillpage(mmobj_t *o, pframe_t *pf);
static int  shadow_dirtypage(mmobj_t *o, pframe_t *pf);
static int  shadow_cleanpage(mmobj_t *o, pframe_t *pf);

static mmobj_ops_t shadow_mmobj_ops = {
        .ref = shadow_ref,
        .put = shadow_put,
        .lookuppage = shadow_lookuppage,
        .fillpage  = shadow_fillpage,
        .dirtypage = shadow_dirtypage,
        .cleanpage = shadow_cleanpage
};

/*
 * This function is called at boot time to initialize the
 * shadow page sub system. Currently it only initializes the
 * shadow_allocator object.
 */
void
shadow_init()
{
        /*NOT_YET_IMPLEMENTED("VM: shadow_init");*/
        /*similar to vmmap creation in vmmap.c*/
        shadow_allocator = slab_allocator_create("shadow", sizeof(mmobj_t));
        
        KASSERT(shadow_allocator);
        dbg(DBG_PRINT, "(GRADING3A 6.a)\n");
	
}

/*
 * You'll want to use the shadow_allocator to allocate the mmobj to
 * return, then then initialize it. Take a look in mm/mmobj.h for
 * macros which can be of use here. Make sure your initial
 * reference count is correct.
 */
mmobj_t *
shadow_create()
{
        /*NOT_YET_IMPLEMENTED("VM: shadow_create");*/

        mmobj_t* shadowObj = (mmobj_t*) slab_obj_alloc(shadow_allocator);

        if(shadowObj)
        {
	  dbg(DBG_PRINT, "(GRADING3D 2)\n");
          /*Initializing shadow object*/
          mmobj_init(shadowObj, &shadow_mmobj_ops);
          /*Increasing ref count*/
          shadowObj->mmo_refcount=1;
          shadowObj->mmo_un.mmo_bottom_obj=NULL;
        }
	dbg(DBG_PRINT, "(GRADING3D 2)\n");
        return shadowObj;
}

/* Implementation of mmobj entry points: */

/*
 * Increment the reference count on the object.
 */
static void
shadow_ref(mmobj_t *o)
{
        /*NOT_YET_IMPLEMENTED("VM: shadow_ref");*/
        KASSERT(o && (0 < o->mmo_refcount) && (&shadow_mmobj_ops == o->mmo_ops)); 
        dbg(DBG_PRINT, "(GRADING3A 6.b)\n");
        (o->mmo_refcount)++;

}

/*
 * Decrement the reference count on the object. If, however, the
 * reference count on the object reaches the number of resident
 * pages of the object, we can conclude that the object is no
 * longer in use and, since it is a shadow object, it will never
 * be used again. You should unpin and uncache all of the object's
 * pages and then free the object itself.
 */
static void
shadow_put(mmobj_t *o)
{
        /*NOT_YET_IMPLEMENTED("VM: shadow_put");*/

        KASSERT(o && (0 < o->mmo_refcount) && (&shadow_mmobj_ops == o->mmo_ops));
        dbg(DBG_PRINT, "(GRADING3A 6.c)\n");
	
        o->mmo_refcount--;

        if(o->mmo_refcount == o->mmo_nrespages)
        {
          	
          	pframe_t* pframe;
          	list_iterate_begin(&o->mmo_respages,pframe,pframe_t,pf_olink)
          	{
           		/* while(pframe_is_busy(pframe))
            	        {	
				dbg(DBG_PRINT, "(Untested Code Path)\n");
              			sched_sleep_on(&pframe->pf_waitq);
            		}*/

           		 if(pframe_is_pinned(pframe))
            		{
				dbg(DBG_PRINT, "(GRADING3D 2)\n");
              			pframe_unpin(pframe);
            		}
            
            		/*if(pframe_is_dirty(pframe))
           		{
				dbg(DBG_PRINT, "(Untested Code Path)\n");
              			pframe_clean(pframe);
            		}*/
			dbg(DBG_PRINT, "(GRADING3D 2)\n");
            		 o->mmo_nrespages--;
			pframe_free(pframe);
         	 }list_iterate_end();
         	dbg(DBG_PRINT, "(GRADING3D 2)\n");	
            	o->mmo_shadowed->mmo_ops->put(o->mmo_shadowed);
		o->mmo_shadowed = NULL;
		slab_obj_free(shadow_allocator,o);
        }
}

/* This function looks up the given page in this shadow object. The
 * forwrite argument is true if the page is being looked up for
 * writing, false if it is being looked up for reading. This function
 * must handle all do-not-copy-on-not-write magic (i.e. when forwrite
 * is false find the first shadow object in the chain which has the
 * given page resident). copy-on-write magic (necessary when forwrite
 * is true) is handled in shadow_fillpage, not here. It is important to
 * use iteration rather than recursion here as a recursive implementation
 * can overflow the kernel stack when looking down a long shadow chain */
static int
shadow_lookuppage(mmobj_t *o, uint32_t pagenum, int forwrite, pframe_t **pf)
{
        /*NOT_YET_IMPLEMENTED("VM: shadow_lookuppage");*/
	dbg(DBG_PRINT, "(GRADING3D 2)\n");
	pframe_t *page_frame = NULL;
	mmobj_t *o1 = o;
	if (forwrite!=0)
	{
		dbg(DBG_PRINT, "(GRADING3D 2)\n");
        	return pframe_get(o, pagenum, pf);
	}
	else
	{
		while (page_frame == NULL && o1->mmo_shadowed != NULL)
		{
			dbg(DBG_PRINT, "(GRADING3D 2)\n");
        		page_frame = pframe_get_resident(o1, pagenum);
        		o1 = o1->mmo_shadowed;
    		}
		if (page_frame)
		{
			dbg(DBG_PRINT, "(GRADING3D 2)\n");
			*pf = page_frame;
		}
		else
		{
			dbg(DBG_PRINT, "(GRADING3D 2)\n");
        		return pframe_lookup(o1, pagenum, 0, pf);
		}
		dbg(DBG_PRINT, "(GRADING3D 2)\n");
    		return 0;
	}
	


}

/* As per the specification in mmobj.h, fill the page frame starting
 * at address pf->pf_addr with the contents of the page identified by
 * pf->pf_obj and pf->pf_pagenum. This function handles all
 * copy-on-write magic (i.e. if there is a shadow object which has
 * data for the pf->pf_pagenum-th page then we should take that data,
 * if no such shadow object exists we need to follow the chain of
 * shadow objects all the way to the bottom object and take the data
 * for the pf->pf_pagenum-th page from the last object in the chain).
 * It is important to use iteration rather than recursion here as a 
 * recursive implementation can overflow the kernel stack when 
 * looking down a long shadow chain */
static int
shadow_fillpage(mmobj_t *o, pframe_t *pf)
{
        /*NOT_YET_IMPLEMENTED("VM: shadow_fillpage");*/
         KASSERT(pframe_is_busy(pf));
         dbg(DBG_PRINT, "(GRADING3A 6.d)\n");
         KASSERT(!pframe_is_pinned(pf));
         dbg(DBG_PRINT, "(GRADING3A 6.d)\n");

         pframe_t* fillfrom_pf = NULL;
         int retval = 0;

         /*the iteration logic is implemented in shadow_lookup()*/
         retval = shadow_lookuppage(o->mmo_shadowed, pf->pf_pagenum, 0, &fillfrom_pf);

         if(retval != 0)
         {
		dbg(DBG_PRINT, "(GRADING3D 3)\n");
	        return -1;
         }

         if(fillfrom_pf)
         {
           /*filling the page frame starting at address pf->pf_addr with contents identified by pd->pf_pagenum*/
         /*  pframe_set_dirty(pf);*/
	   	dbg(DBG_PRINT, "(GRADING3D 2)\n");
           	pframe_pin(pf);
           	memcpy(pf->pf_addr, fillfrom_pf->pf_addr, PAGE_SIZE);
         }
        /* else
         {
		dbg(DBG_PRINT, "(Untested Code Path)\n");
           	return -1;
         }*/
	 dbg(DBG_PRINT, "(GRADING3D 2)\n");
         return 0;
}

/* These next two functions are not difficult. */

static int
shadow_dirtypage(mmobj_t *o, pframe_t *pf)
{

        NOT_YET_IMPLEMENTED("VM: shadow_dirtypage");
        /*DOUBT: Not sure if this function is complete*/
        /*What should we return if pframe is already dirty?*/
        /*int retval = 0;

        if(!pframe_is_dirty(pf))
        {
           //following function is a #define in pframe.h. We cannot get it's return value.
           //We may have to use pframe_dirty
	   //also may need to check if pfrae is busy before that
		dbg(DBG_PRINT, "(Untested Code Path)\n");
          	 pframe_set_dirty(pf);
        }
	dbg(DBG_PRINT, "(Untested Code Path)\n");
        return retval;*/
	return -1;
}

static int
shadow_cleanpage(mmobj_t *o, pframe_t *pf)
{

        NOT_YET_IMPLEMENTED("VM: shadow_cleanpage");
      /*  pframe_t* fillto_pf = NULL;
        int retval = 0;

        retval = shadow_lookuppage(o, pf->pf_pagenum, 1, &fillto_pf);

        if(retval != 0)
        {
		dbg(DBG_PRINT, "(Untested Code Path)\n");
          	return -1;
        }

        if(fillto_pf)
        {
		dbg(DBG_PRINT, "(Untested Code Path)\n");
          	memcpy(fillto_pf->pf_addr, pf->pf_addr, PAGE_SIZE);
        }
        else
        {
		dbg(DBG_PRINT, "(Untested Code Path)\n");
          	return -1;
        }
      	dbg(DBG_PRINT, "(Untested Code Path)\n");*/
        return -1;

}
