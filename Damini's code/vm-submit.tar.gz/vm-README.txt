Documentation for Kernel Assignment 3
=====================================

+-------------+
| BUILD & RUN |
+-------------+

Comments: Type "make" to create an executable called weenix and type "./weenix -n" to run.

Please also test part E : 1,3,4,5 of the grading guidelines along with A,B,C and D.

+-----------------+
| SKIP (Optional) |
+-----------------+

None.

+---------+
| GRADING |
+---------+

(A.1) In mm/pframe.c:
    (a) In pframe_pin(): 1 out of 1 pt
    (b) In pframe_unpin(): 1 out of 1 pt

(A.2) In vm/mmap.c:
    (a) In do_mmap(): 2 out of 2 pts
    (b) In do_munmap(): 2 out of 2 pts

(A.3) In vm/vmmap.c:
    (a) In vmmap_destroy(): 2 out of 2 pts
    (b) In vmmap_insert(): 2 out of 2 pts
    (c) In vmmap_find_range(): 2 out of 2 pts
    (d) In vmmap_lookup(): 1 out of 1 pt
    (e) In vmmap_is_range_empty(): 1 out of 1 pt
    (f) In vmmap_map(): 7 out of 7 pts

(A.4) In vm/anon.c:
    (a) In anon_init(): 1 out of 1 pt
    (b) In anon_ref(): 1 out of 1 pt
    (c) In anon_put():  out of 1 pt
    (d) In anon_fillpage(): 1 out of 1 pt

(A.5) In fs/vnode.c:
    (a) In special_file_mmap(): 2 out of 2 pts

(A.6) In vm/shadow.c:
    (a) In shadow_init(): 1 out of 1 pt
    (b) In shadow_ref(): 1 out of 1 pt
    (c) In shadow_put(): 1 out of 1 pts
    (d) In shadow_fillpage(): 2 out of 2 pts

(A.7) In proc/fork.c:
    (a) In do_fork(): 6 out of 6 pts

(A.8) In proc/kthread.c:
    (a) In kthread_clone(): 2 out of 2 pts

(B.1) /usr/bin/hello (3 out of 3 pts)
(B.2) /bin/uname -a (3 out of 3 pts)
(B.3) /usr/bin/args ab cde fghi j (3 out of 3 pts)
(B.4) /usr/bin/fork-and-wait (5 out of 5 pts)

(C.1) /usr/bin/segfault (1 out of 1 pt)

(D.2) /usr/bin/vfstest (7 out of 7 pts)
(D.3) /usr/bin/memtest (6.75 out of 7 pts) : one test(test no 266) failed out of 330.
(D.4) /usr/bin/eatmem (7 out of 7 pts)
(D.5) /usr/bin/forkbomb (7 out of 7 pts)
(D.6) /usr/bin/stress (7 out of 7 pts)

(E.1) /usr/bin/vfstest (1 out of 1 pt)
(E.2) /usr/bin/memtest (0 out of 1 pt) : one test(test no 266) failed out of 330.
(E.3) /usr/bin/eatmem (1 out of 1 pt)
(E.4) /usr/bin/forkbomb (1 out of 1 pt)
(E.5) /usr/bin/stress (1 out of 1 pt)

(F) Self-checks: (10 out of 10 pts)
    Comments: By running the tests in section B,C and D all code paths are exercised.

Missing required section(s) in README file (vm-README.txt): -0 pt
Submitted binary file : -0 pt
Submitted extra (unmodified) file : -0 pt
Wrong file location in submission : -0 pt
Use dbg_print(...) instead of dbg(DBG_PRINT, ...) : -0 pt
Not properly indentify which dbg() printout is for which item in the grading guidelines : -0 pt
Cannot compile : -0 pt
Compiler warnings : -0 pt
"make clean" : -0 pt
Useless KASSERT : -0 pt
Insufficient/Confusing dbg : -0 pt
Kernel panic : -0 pt
Cannot halt kernel cleanly : -0 pt

+------+
| BUGS |
+------+

Comments: None

+---------------------------+
| CONTRIBUTION FROM MEMBERS |
+---------------------------+

If not equal-share contribution, please list percentages.

Equal-share contribution from all members.

+------------------+
| OTHER (Optional) |
+------------------+

Special DBG setting in Config.mk for certain tests: None
Comments on deviation from spec (you will still lose points, but it's better to let the grader know): None
General comments on design decisions: None
