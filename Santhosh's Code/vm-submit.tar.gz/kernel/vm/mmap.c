/******************************************************************************/
/* Important Summer 2015 CSCI 402 usage information:                          */
/*                                                                            */
/* This fils is part of CSCI 402 kernel programming assignments at USC.       */
/* Please understand that you are NOT permitted to distribute or publically   */
/*         display a copy of this file (or ANY PART of it) for any reason.    */
/* If anyone (including your prospective employer) asks you to post the code, */
/*         you must inform them that you do NOT have permissions to do so.    */
/* You are also NOT permitted to remove or alter this comment block.          */
/* If this comment block is removed or altered in a submitted file, 20 points */
/*         will be deducted.                                                  */
/******************************************************************************/

#include "globals.h"
#include "errno.h"
#include "types.h"

#include "mm/mm.h"
#include "mm/tlb.h"
#include "mm/mman.h"
#include "mm/page.h"

#include "proc/proc.h"

#include "util/string.h"
#include "util/debug.h"

#include "fs/vnode.h"
#include "fs/vfs.h"
#include "fs/file.h"
#include "fs/stat.h"

#include "vm/vmmap.h"
#include "vm/mmap.h"

/*
 * This function implements the mmap(2) syscall, but only
 * supports the MAP_SHARED, MAP_PRIVATE, MAP_FIXED, and
 * MAP_ANON flags.
 *
 * Add a mapping to the current process's address space.
 * You need to do some error checking; see the ERRORS section
 * of the manpage for the problems you should anticipate.
 * After error checking most of the work of this function is
 * done by vmmap_map(), but remember to clear the TLB.
 */
int
do_mmap(void *addr, size_t len, int prot, int flags,
        int fd, off_t off, void **ret)
{
        /*NOT_YET_IMPLEMENTED("VM: do_mmap");
        return -1;*/
        if (addr != NULL) {
            dbg(DBG_PRINT, "(GRADING3D 1), Valid address in do_mmap\n");
            if ((uintptr_t)addr < USER_MEM_LOW || (uintptr_t)addr > USER_MEM_HIGH) {
             dbg(DBG_PRINT, "(GRADING3D 1), Address is not in valid range\n");
                return -EINVAL;
            }
            /*if ((uintptr_t)addr + len < USER_MEM_LOW || (uintptr_t)addr + len > USER_MEM_HIGH) {
             dbg(DBG_VM, "(GRADING3D), Endaddress is not in valid range\n");
                return -EINVAL;
            }
            if (!PAGE_ALIGNED(addr) || !PAGE_ALIGNED(off)) {
             dbg(DBG_VM, "(GRADING3B), Address and offset are not PAGE ALIGNED\n");
                return -EINVAL;
            }*/
        }
        if ((addr == NULL && (flags & MAP_FIXED)) || flags == 0 || flags == MAP_TYPE) {
		dbg(DBG_PRINT, "(GRADING3D 1) Invalid Flags\n");
		return -EINVAL;
	}
	if (!PAGE_ALIGNED(addr) || !PAGE_ALIGNED(off) || len == 0 || sizeof(len) == NULL || len == (size_t)-1) {
		dbg(DBG_PRINT, "(GRADING3D 1) Address not page aligned\n");
		return -EINVAL;
	}
        if ((fd < 0 || fd >= NFILES || (curproc->p_files[fd]==NULL)) && !(flags & MAP_ANON)){
             dbg(DBG_PRINT, "(GRADING3D 1), file descriptor fd is not valid\n");
	    return -EBADF;
	}

	if (flags == MAP_SHARED && (prot & PROT_WRITE) && (!(curproc->p_files[fd]->f_mode & FMODE_READ) || !(curproc->p_files[fd]->f_mode &  FMODE_WRITE))) {
             dbg(DBG_PRINT, "(GRADING3D 1), Access permissions denied\n");
		return -EACCES;
	}
        uint32_t num_pages = 0;
        while(len > PAGE_SIZE) {
           len = len - PAGE_SIZE;
           num_pages++;
        }
        if (len > 0) {
            dbg(DBG_VM, "(GRADING3B 1), len not page aligned\n");
            num_pages++;
        }
	file_t *myfile = NULL;
        if (!(flags & MAP_ANON)) {
            dbg(DBG_VM, "(GRADING3B 1), not an anon object\n");
            myfile = fget(fd);
        }
        vnode_t *myvnode = NULL;
	if (myfile) {
            dbg(DBG_VM, "(GRADING3B 1), setting file vnode to vnode\n");
            myvnode = myfile->f_vnode;
        }
	vmarea_t *myarea ;
	vmmap_map(curproc->p_vmmap, myvnode, ADDR_TO_PN(addr),num_pages, prot, flags, off,VMMAP_DIR_HILO,&myarea);
        if ((uintptr_t)PN_TO_ADDR(myarea->vma_start) < USER_MEM_LOW || (uintptr_t)PN_TO_ADDR(myarea->vma_end) > USER_MEM_HIGH) {
            return (int)MAP_FAILED;
        }
	int flag = 0;
        if (myfile) fput(myfile);
	uintptr_t ret_addr = 0;
	if (addr != NULL) {
            dbg(DBG_PRINT, "(GRADING3D 1), if addr is not null, return the page number of addr\n");
            ret_addr = (uintptr_t)addr;
            if(ret) {
		dbg(DBG_PRINT,"(GRADING3D 1)\n");
               *ret = (void*)ret_addr;
            }
            tlb_flush_range(ret_addr,num_pages);
            pagedir_t *pd = pt_get();
            pt_unmap_range(pd, ret_addr, ret_addr + (uintptr_t)(num_pages * PAGE_SIZE));
        } else {
            dbg(DBG_PRINT, "(GRADING3D 1), if addr is null, return the area start page number\n");
	    ret_addr = (uintptr_t)PN_TO_ADDR(myarea->vma_start);
            if(ret) {
               dbg(DBG_PRINT,"(GRADING3D 1)\n");
               *ret = (void*)ret_addr;
            }
            tlb_flush_range(ret_addr,num_pages);
            pagedir_t *pd = pt_get();
            pt_unmap_range(pd, ret_addr, (uintptr_t)PN_TO_ADDR(myarea->vma_start + num_pages));
	}
	/*pagedir_t *pd = pt_get();
	if(flag){
	    tlb_flush_range(ret_addr,num_pages);
	    if((ret_addr >= USER_MEM_LOW) && (ret_addr + (uintptr_t)PN_TO_ADDR(num_pages) <= USER_MEM_HIGH))
            pt_unmap_range(pd, ret_addr, ret_addr + (uintptr_t)PN_TO_ADDR(num_pages));
	}*/
        KASSERT(NULL != curproc->p_pagedir);
        dbg(DBG_PRINT, "(GRADING3A 2.a), pagedir address is not null\n");
	return 0;

}


/*
 * This function implements the munmap(2) syscall.
 *
 * As with do_mmap() it should perform the required error checking,
 * before calling upon vmmap_remove() to do most of the work.
 * Remember to clear the TLB.
 */
int
do_munmap(void *addr, size_t len)
{
        /*NOT_YET_IMPLEMENTED("VM: do_munmap");
        return -1;*/
        if(len == 0 || len == (size_t) - 1){
                dbg(DBG_PRINT, "(GRADING3D 1), Invalid size\n");
		return -EINVAL;
	}
	if ((uintptr_t)addr < USER_MEM_LOW || (uintptr_t)addr > USER_MEM_HIGH) {
		dbg(DBG_PRINT, "(GRADING3D 1), invalid address range\n");
		return -EINVAL;
	}
	if ((uintptr_t)addr + len < USER_MEM_LOW || (uintptr_t)addr + len > USER_MEM_HIGH) {
        	dbg(DBG_PRINT, "(GRADING3D 5), invalid end address range\n");
		return -EINVAL;
	}

        uint32_t num_pages = 0;
	while (len > PAGE_SIZE) {
		num_pages ++;
		len = len - PAGE_SIZE;
	}
	if (len > 0) {
        	dbg(DBG_PRINT, "(GRADING3D 1), finding the number of pages\n");
		num_pages++;

	}

	vmmap_remove(curproc->p_vmmap,ADDR_TO_PN(addr),(uint32_t)num_pages);
	tlb_flush_range((uintptr_t)addr,num_pages);
	if (((uintptr_t)addr >= USER_MEM_LOW) && ((uintptr_t)PN_TO_ADDR(ADDR_TO_PN(addr) + num_pages) <= USER_MEM_HIGH)) {
        	dbg(DBG_PRINT, "(GRADING3D 1), unmapping the address range\n");
    		pt_unmap_range(pt_get(), (uintptr_t)addr, (uintptr_t)PN_TO_ADDR(ADDR_TO_PN(addr) + num_pages));
        }
	return 0;

}

