/******************************************************************************/
/* Important Summer 2015 CSCI 402 usage information:                          */
/*                                                                            */
/* This fils is part of CSCI 402 kernel programming assignments at USC.       */
/* Please understand that you are NOT permitted to distribute or publically   */
/*         display a copy of this file (or ANY PART of it) for any reason.    */
/* If anyone (including your prospective employer) asks you to post the code, */
/*         you must inform them that you do NOT have permissions to do so.    */
/* You are also NOT permitted to remove or alter this comment block.          */
/* If this comment block is removed or altered in a submitted file, 20 points */
/*         will be deducted.                                                  */
/******************************************************************************/

#include "kernel.h"
#include "errno.h"
#include "globals.h"

#include "vm/vmmap.h"
#include "vm/shadow.h"
#include "vm/anon.h"

#include "proc/proc.h"

#include "util/debug.h"
#include "util/list.h"
#include "util/string.h"
#include "util/printf.h"

#include "fs/vnode.h"
#include "fs/file.h"
#include "fs/fcntl.h"
#include "fs/vfs_syscall.h"

#include "mm/slab.h"
#include "mm/page.h"
#include "mm/mm.h"
#include "mm/mman.h"
#include "mm/mmobj.h"

static slab_allocator_t *vmmap_allocator;
static slab_allocator_t *vmarea_allocator;

void
vmmap_init(void)
{
        vmmap_allocator = slab_allocator_create("vmmap", sizeof(vmmap_t));
        KASSERT(NULL != vmmap_allocator && "failed to create vmmap allocator!");
        vmarea_allocator = slab_allocator_create("vmarea", sizeof(vmarea_t));
        KASSERT(NULL != vmarea_allocator && "failed to create vmarea allocator!");
}

vmarea_t *
vmarea_alloc(void)
{
        vmarea_t *newvma = (vmarea_t *) slab_obj_alloc(vmarea_allocator);
        if (newvma) {
                newvma->vma_vmmap = NULL;
        }
        return newvma;
}

void
vmarea_free(vmarea_t *vma)
{
        KASSERT(NULL != vma);
        slab_obj_free(vmarea_allocator, vma);
}

/* a debugging routine: dumps the mappings of the given address space. */
size_t
vmmap_mapping_info(const void *vmmap, char *buf, size_t osize)
{
        KASSERT(0 < osize);
        KASSERT(NULL != buf);
        KASSERT(NULL != vmmap);

        vmmap_t *map = (vmmap_t *)vmmap;
        vmarea_t *vma;
        ssize_t size = (ssize_t)osize;

        int len = snprintf(buf, size, "%21s %5s %7s %8s %10s %12s\n",
                           "VADDR RANGE", "PROT", "FLAGS", "MMOBJ", "OFFSET",
                           "VFN RANGE");

        list_iterate_begin(&map->vmm_list, vma, vmarea_t, vma_plink) {
                size -= len;
                buf += len;
                if (0 >= size) {
                        goto end;
                }

                len = snprintf(buf, size,
                               "%#.8x-%#.8x  %c%c%c  %7s 0x%p %#.5x %#.5x-%#.5x\n",
                               vma->vma_start << PAGE_SHIFT,
                               vma->vma_end << PAGE_SHIFT,
                               (vma->vma_prot & PROT_READ ? 'r' : '-'),
                               (vma->vma_prot & PROT_WRITE ? 'w' : '-'),
                               (vma->vma_prot & PROT_EXEC ? 'x' : '-'),
                               (vma->vma_flags & MAP_SHARED ? " SHARED" : "PRIVATE"),
                               vma->vma_obj, vma->vma_off, vma->vma_start, vma->vma_end);
        } list_iterate_end();

end:
        if (size <= 0) {
                size = osize;
                buf[osize - 1] = '\0';
        }
        /*
        KASSERT(0 <= size);
        if (0 == size) {
                size++;
                buf--;
                buf[0] = '\0';
        }
        */
        return osize - size;
}

/* Create a new vmmap, which has no vmareas and does
 * not refer to a process. */
vmmap_t *
vmmap_create(void)
{
        /*NOT_YET_IMPLEMENTED("VM: vmmap_create");
        return NULL;*/
        vmmap_t *new_vm = (vmmap_t *) slab_obj_alloc(vmmap_allocator);
        list_init(&(new_vm->vmm_list));
        new_vm->vmm_proc = NULL;
        dbg(DBG_PRINT,"(GRADING3B 1), Leaving the function vmmap_create\n");
	return new_vm;
}

/* Removes all vmareas from the address space and frees the
 * vmmap struct. */
void
vmmap_destroy(vmmap_t *map)
{
        /*NOT_YET_IMPLEMENTED("VM: vmmap_destroy");*/
        KASSERT(NULL != map);
        dbg(DBG_PRINT,"(GRADING3A 3.a), Destroying the valid map in vmmap_destroy\n");
        dbg(DBG_PRINT,"(GRADING3B 1), Destroying the valid map in vmmap_destroy\n");
	 vmarea_t *vma;
	 list_iterate_begin(&(map->vmm_list),vma,vmarea_t,vma_plink) {
	 	if (list_link_is_linked(&(vma->vma_olink))) {
        		dbg(DBG_PRINT,"(GRADING3B 1), Removing the object link in vmmap_destroy\n");
             		list_remove(&(vma->vma_olink));
         	}
	 	list_remove(&(vma->vma_plink));
	 	vma->vma_obj->mmo_ops->put(vma->vma_obj);
	 	vmarea_free(vma);
	 } list_iterate_end();

 	 slab_obj_free(vmmap_allocator,map);
        dbg(DBG_PRINT,"(GRADING3B 1), Leaving the function vmmap_destroy\n");
}

/* Add a vmarea to an address space. Assumes (i.e. asserts to some extent)
 * the vmarea is valid.  This involves finding where to put it in the list
 * of VM areas, and adding it. Don't forget to set the vma_vmmap for the
 * area. */
void
vmmap_insert(vmmap_t *map, vmarea_t *newvma)
{
       /*NOT_YET_IMPLEMENTED("VM: vmmap_insert");*/
         KASSERT(NULL != map && NULL != newvma);
         dbg(DBG_PRINT,"(GRADING3A 3.b), Inserting the valid vmarea into vmmap in vmmap_insert\n");
         KASSERT(NULL == newvma->vma_vmmap);
         dbg(DBG_PRINT,"(GRADING3A 3.b), vmarea is not mapped to any other map before inserting into this map\n");
         KASSERT(newvma->vma_start < newvma->vma_end);
         dbg(DBG_PRINT,"(GRADING3A 3.b), vmarea should have valid start address\n");
         KASSERT(ADDR_TO_PN(USER_MEM_LOW) <= newvma->vma_start && ADDR_TO_PN(USER_MEM_HIGH) >= newvma->vma_end);
         dbg(DBG_PRINT,"(GRADING3A 3.b), vmarea should have valid address range\n");
         dbg(DBG_PRINT,"(GRADING3B 1), vmarea should have valid address range\n");
      	 newvma->vma_vmmap=map;
	 if (list_empty(&(map->vmm_list))) {
             dbg(DBG_PRINT,"(GRADING3B 1), vmmap is empty, inserting the vmarea without comparing\n");
	     list_insert_tail(&(map->vmm_list),&(newvma->vma_plink));
	     return;
	 } else {
             dbg(DBG_PRINT,"(GRADING3B 1), vmmap is non-empty, entering into comparing block\n");
	     vmarea_t *myarea;
	     list_iterate_begin(&(map->vmm_list), myarea, vmarea_t,vma_plink){
		 if (myarea->vma_start>newvma->vma_start){
                     dbg(DBG_PRINT,"(GRADING3D 1), vmarea is inserting at a valid place\n");
		     list_insert_before(&(myarea->vma_plink),&(newvma->vma_plink));
		     return;
		 }
             } list_iterate_end();
             dbg(DBG_PRINT,"(GRADING3B 1), vmarea is inserting at last in the list\n");
	     list_insert_tail(&(map->vmm_list),&(newvma->vma_plink));
	     return;
	 }
}

/* Find a contiguous range of free virtual pages of length npages in
 * the given address space. Returns starting vfn for the range,
 * without altering the map. Returns -1 if no such range exists.
 *
 * Your algorithm should be first fit. If dir is VMMAP_DIR_HILO, you
 * should find a gap as high in the address space as possible; if dir
 * is VMMAP_DIR_LOHI, the gap should be as low as possible. */
int
vmmap_find_range(vmmap_t *map, uint32_t npages, int dir)
{
        /*NOT_YET_IMPLEMENTED("VM: vmmap_find_range");
        return -1;*/
	int ret=0,k=0;
        dbg(DBG_PRINT,"(GRADING3B 1), vmmap is non-empty, so we need to check whether the range is available\n");
	vmarea_t *myarea;
	if (dir == VMMAP_DIR_HILO) { 
                dbg(DBG_PRINT,"(GRADING3B 1), dir is VMMAP_DIR_HILO\n");
		list_iterate_reverse(&map->vmm_list,myarea,vmarea_t,vma_plink){
		    if ((myarea->vma_plink.l_next==&map->vmm_list) && myarea->vma_end + npages <= ADDR_TO_PN(USER_MEM_HIGH)){
                        dbg(DBG_PRINT,"(GRADING3B 1), checking the block after the last vmarea\n");
                        return (ADDR_TO_PN(USER_MEM_HIGH) - npages);
		    }
                    if (myarea->vma_start - npages >= ADDR_TO_PN(USER_MEM_LOW)) {
		        k = vmmap_is_range_empty(map,myarea->vma_start-npages,npages);
		        if (k == 1) {
                            dbg(DBG_PRINT,"(GRADING3D 1), range of npages is available somewhere in middle2\n");
		            return myarea->vma_start-npages;
		        }
                    } else continue;
		} list_iterate_end();
	}
        dbg(DBG_PRINT,"(GRADING3D 2), range of npages is not available in the map\n");
        return -1;
}

/* Find the vm_area that vfn lies in. Simply scan the address space
 * looking for a vma whose range covers vfn. If the page is unmapped,
 * return NULL. */
vmarea_t *
vmmap_lookup(vmmap_t *map, uint32_t vfn)
{
        /*NOT_YET_IMPLEMENTED("VM: vmmap_lookup");
        return NULL;*/
        KASSERT(NULL != map);
        dbg(DBG_PRINT,"(GRADING3A 3.c), Valid map to lookup\n");
        dbg(DBG_PRINT,"(GRADING3B 1), Valid map to lookup\n");
	vmarea_t *myarea;
	list_iterate_begin(&(map->vmm_list), myarea, vmarea_t,vma_plink){
		if ( (vfn>=myarea->vma_start) && (vfn<myarea->vma_end) ){
                	dbg(DBG_PRINT,"(GRADING3B 1), vmarea with vfn is found\n");
			return myarea;
		}
        } list_iterate_end();
        dbg(DBG_PRINT,"(GRADING3D 1), vmarea with vfn is not found\n");
        return NULL;
}

/* Allocates a new vmmap containing a new vmarea for each area in the
 * given map. The areas should have no mmobjs set yet. Returns pointer
 * to the new vmmap on success, NULL on failure. This function is
 * called when implementing fork(2). */
vmmap_t *
vmmap_clone(vmmap_t *map)
{
        /*NOT_YET_IMPLEMENTED("VM: vmmap_clone");
        return NULL;*/
	vmmap_t *myclone = vmmap_create();
	vmarea_t *myarea;
        dbg(DBG_PRINT,"(GRADING3B 1), cloning all the vmareas in the vmmap\n");
        list_iterate_begin(&(map->vmm_list), myarea, vmarea_t,vma_plink){
	    vmarea_t *clonearea = vmarea_alloc();
	    clonearea->vma_start = myarea->vma_start;
	    clonearea->vma_end = myarea->vma_end;
	    clonearea->vma_off = myarea->vma_off;
	    clonearea->vma_prot = myarea->vma_prot;
	    clonearea->vma_flags = myarea->vma_flags;
	    clonearea->vma_obj = myarea->vma_obj;
	    clonearea->vma_obj->mmo_ops->ref(clonearea->vma_obj);
	    list_link_init(&(clonearea->vma_plink));
	    list_link_init(&(clonearea->vma_olink));
	    vmmap_insert(myclone, clonearea);
	} list_iterate_end();
        dbg(DBG_PRINT,"(GRADING3B 1), cloning of vmmap is done\n");
	return myclone;

}

/* Insert a mapping into the map starting at lopage for npages pages.
 * If lopage is zero, we will find a range of virtual addresses in the
 * process that is big enough, by using vmmap_find_range with the same
 * dir argument.  If lopage is non-zero and the specified region
 * contains another mapping that mapping should be unmapped.
 *
 * If file is NULL an anon mmobj will be used to create a mapping
 * of 0's.  If file is non-null that vnode's file will be mapped in
 * for the given range.  Use the vnode's mmap operation to get the
 * mmobj for the file; do not assume it is file->vn_obj. Make sure all
 * of the area's fields except for vma_obj have been set before
 * calling mmap.
 *
 * If MAP_PRIVATE is specified set up a shadow object for the mmobj.
 *
 * All of the input to this function should be valid (KASSERT!).
 * See mmap(2) for for description of legal input.
 * Note that off should be page aligned.
 *
 * Be very careful about the order operations are performed in here. Some
 * operation are impossible to undo and should be saved until there
 * is no chance of failure.
 *
 * If 'new' is non-NULL a pointer to the new vmarea_t should be stored in it.
 */
int
vmmap_map(vmmap_t *map, vnode_t *file, uint32_t lopage, uint32_t npages,
          int prot, int flags, off_t off, int dir, vmarea_t **new)
{
        /*NOT_YET_IMPLEMENTED("VM: vmmap_map");
        return -1;*/
        KASSERT(NULL != map);
        dbg(DBG_PRINT,"(GRADING3A 3.d), valid map is provided\n");
        KASSERT(0 < npages);
        dbg(DBG_PRINT,"(GRADING3A 3.d), number of pages to map is valid\n");
        KASSERT((MAP_SHARED & flags) || (MAP_PRIVATE & flags));
        dbg(DBG_PRINT,"(GRADING3A 3.d), flags is valid\n");
        KASSERT((0 == lopage) || (ADDR_TO_PN(USER_MEM_LOW) <= lopage));
        dbg(DBG_PRINT,"(GRADING3A 3.d), start page number is valid\n");
        KASSERT((0 == lopage) || (ADDR_TO_PN(USER_MEM_HIGH) >= (lopage + npages)));
        dbg(DBG_PRINT,"(GRADING3A 3.d), end page number is valid\n");
        KASSERT(PAGE_ALIGNED(off));
        dbg(DBG_PRINT,"(GRADING3A 3.d), offset page number is page_aligned address\n");
	int startpn=0, loflag = 0;

	if(lopage == 0){
		dbg(DBG_PRINT,"(GRADING3B 1), Lopage is NULL\n");
		loflag = 1;
	}

	if (loflag) {
            dbg(DBG_PRINT,"(GRADING3D 1), Entering lopage is 0\n");
	    startpn = vmmap_find_range( map, npages, dir);
            if (startpn < 0){
                dbg(DBG_PRINT,"(GRADING3D 2), npages range is not found\n");
		return -ENOMEM;
	    }
	} else{
            dbg(DBG_PRINT,"(GRADING3B 1), entering lopage non-zero\n");
	    int ret = vmmap_is_range_empty(map,lopage,npages);
	    if (ret == 0){
                dbg(DBG_PRINT,"(GRADING3D 1), map at the provided range already exists, so removing\n");
		vmmap_remove(map,lopage,npages);
	    }
	    startpn=lopage;
	}

	if(startpn){
	
	dbg(DBG_PRINT,"(GRADING3B 1), Startpn not equal to NULL\n");

	vmarea_t * myarea=vmarea_alloc();
	myarea->vma_start=startpn;
        myarea->vma_end = startpn+npages;
        myarea->vma_off = ADDR_TO_PN(off);
        myarea->vma_prot = prot;
        myarea->vma_flags = flags;
	list_link_init(&myarea->vma_olink);

	int fileflag = 0, PrivateFlag = 0;

	if((file == NULL) || (flags & MAP_ANON)){
	   dbg(DBG_PRINT,"(GRADING3B 1), Either file is equal to NULL or MAP_ANON is set in flags\n");
	   fileflag = 1;
	}

	if(flags & MAP_PRIVATE){
	   dbg(DBG_PRINT,"(GRADING3B 1), MAP_PRIVATE is set in the flags\n");
	   PrivateFlag = 1;
	}

	if (fileflag) {
            dbg(DBG_PRINT,"(GRADING3B 1), mapping an anon object to vmarea\n");
            mmobj_t *myannon = anon_create();
            myarea->vma_obj = myannon;
	} else {
            dbg(DBG_PRINT,"(GRADING3B 1), mapping a file object to vmarea\n");
       	    mmobj_t *fileobj;
            file->vn_ops->mmap(file,myarea, &fileobj);
            myarea->vma_obj = fileobj;
    	}
	if (PrivateFlag) {
            dbg(DBG_PRINT,"(GRADING3B 1), mapping a shadow object to vmarea\n");
	    mmobj_t *myshadow = shadow_create();
	    myshadow->mmo_shadowed = myarea->vma_obj;			
	    myshadow->mmo_un.mmo_bottom_obj = mmobj_bottom_obj(myarea->vma_obj);
            list_insert_head(&myarea->vma_obj->mmo_un.mmo_vmas, &myarea->vma_olink);
            myarea->vma_obj = myshadow;
    	}
	if(new != NULL){
           dbg(DBG_PRINT,"(GRADING3D 1), returning the vmarea after the mapping is done\n");
	   *new = myarea;
	   goto insert;
	} else {
	   dbg(DBG_PRINT,"(GRADING3B 1), Calling insert\n");
	   goto insert;
	}
insert:	vmmap_insert(map,myarea);
        dbg(DBG_PRINT,"(GRADING3B 1), Mapping in vmmap_map is done\n");
	}
        return 0;

}

/*
 * We have no guarantee that the region of the address space being
 * unmapped will play nicely with our list of vmareas.
 *
 * You must iterate over each vmarea that is partially or wholly covered
 * by the address range [addr ... addr+len). The vm-area will fall into one
 * of four cases, as illustrated below:
 *
 * key:
 *          [             ]   Existing VM Area
 *        *******             Region to be unmapped
 *
 * Case 1:  [   ******    ]
 * The region to be unmapped lies completely inside the vmarea. We need to
 * split the old vmarea into two vmareas. be sure to increment the
 * reference count to the file associated with the vmarea.
 *
 * Case 2:  [      *******]**
 * The region overlaps the end of the vmarea. Just shorten the length of
 * the mapping.
 *
 * Case 3: *[*****        ]
 * The region overlaps the beginning of the vmarea. Move the beginning of
 * the mapping (remember to update vma_off), and shorten its length.
 *
 * Case 4: *[*************]**
 * The region completely contains the vmarea. Remove the vmarea from the
 * list.
 */
int
vmmap_remove(vmmap_t *map, uint32_t lopage, uint32_t npages)
{
        /*NOT_YET_IMPLEMENTED("VM: vmmap_remove");
        return -1;*/
	vmarea_t *myarea;
	if (vmmap_is_range_empty(map, lopage, npages)) {
            dbg(DBG_PRINT,"(GRADING3D 2), No maps exist to remove\n");
	    return 0;
	}

	list_iterate_begin(&map->vmm_list, myarea, vmarea_t, vma_plink){
		int case1 = 0, case2 = 0, case3 = 0, case4 = 0, case5 = 0;
		if (myarea->vma_start >= (lopage + npages) || myarea->vma_end <= lopage){
		   dbg(DBG_PRINT,"(GRADING3B 1), Case1 is true\n");
		   case1 = 1;
		}
		if (myarea->vma_start < lopage  && myarea->vma_end <= lopage+npages){
		   dbg(DBG_PRINT,"(GRADING3B 1), Case2 is true\n");
		   case2 = 1;
		}
		if(myarea->vma_start >= lopage && myarea->vma_end > lopage+npages){
		   dbg(DBG_PRINT,"(GRADING3D 1), Case3 is true\n");
		   case3 = 1;
		}
		if(myarea->vma_start >= lopage && myarea->vma_end <= lopage + npages){
		   dbg(DBG_PRINT,"(GRADING3B 1), Case4 is true\n");
		   case4 = 1;  
		}
		if(myarea->vma_start<lopage && myarea->vma_end>lopage+npages){
		   dbg(DBG_PRINT,"(GRADING3D 2), Case5 is true\n");
		   case5 = 1;
		}


        	if (case1) { 
			dbg(DBG_PRINT, "(GRADING3B 1)\n");
            		continue;
        	} else if (case2){
                        dbg(DBG_PRINT,"(GRADING3D 2), Overlap combination 1\n");
			myarea->vma_end=lopage;
			continue;
		} else if (case3){
                        dbg(DBG_PRINT,"(GRADING3D 2), Overlap combination 2\n");
			myarea->vma_off = myarea->vma_off + lopage - myarea->vma_start + npages;
			myarea->vma_start = npages + lopage;
			continue;
		} else if(case4){
                        dbg(DBG_PRINT,"(GRADING3B 1), Overlap combination 3\n");
			myarea->vma_obj->mmo_ops->put(myarea->vma_obj);
			list_remove(&myarea->vma_plink);
			if (list_link_is_linked(&myarea->vma_olink)) {
                            dbg(DBG_PRINT,"(GRADING3B 1), Removing the link while removing the vmarea from map\n");
			    list_remove(&myarea->vma_olink);
			}
			vmarea_free(myarea);
			continue;
		} else if(case5){
                        dbg(DBG_PRINT,"(GRADING3D 2), Overlap combination 4\n");
			vmarea_t * splitarea = vmarea_alloc();
			splitarea->vma_off = myarea->vma_off;
			splitarea->vma_flags=myarea->vma_flags;
			splitarea->vma_start=myarea->vma_start;
			splitarea->vma_end=lopage;
			splitarea->vma_prot=myarea->vma_prot;
			splitarea->vma_obj=myarea->vma_obj;
			splitarea->vma_vmmap = myarea->vma_vmmap;
			splitarea->vma_obj->mmo_ops->ref(splitarea->vma_obj);
			list_link_init(&splitarea->vma_plink);
			list_insert_before(&myarea->vma_plink, &splitarea->vma_plink);
			list_link_init(&splitarea->vma_olink);
			mmobj_t *bottomobj= mmobj_bottom_obj(myarea->vma_obj);
			if (bottomobj != myarea->vma_obj) {
                                dbg(DBG_PRINT,"(GRADING3D 2), Inserting into mmobj list\n");
				list_insert_head(&bottomobj->mmo_un.mmo_vmas, &splitarea->vma_olink);
			}
			myarea->vma_off = lopage - myarea->vma_start + npages + myarea->vma_off;
			myarea->vma_start = npages + lopage;
			return 0;
		} else continue;
	} list_iterate_end();
        dbg(DBG_PRINT,"(GRADING3B 1), Vmmap is removed, so exiting from vmmap_remove\n");
	return 0;
}

/*
 * Returns 1 if the given address space has no mappings for the
 * given range, 0 otherwise.
 */
int
vmmap_is_range_empty(vmmap_t *map, uint32_t startvfn, uint32_t npages)
{
        /*NOT_YET_IMPLEMENTED("VM: vmmap_is_range_empty");
        return 0;*/
        uint32_t endvfn = startvfn + npages;
        KASSERT((startvfn < endvfn) && (ADDR_TO_PN(USER_MEM_LOW) <= startvfn) && (ADDR_TO_PN(USER_MEM_HIGH) >= endvfn));
        dbg(DBG_PRINT,"(GRADING3A 3.e), address range is valid\n");
	if (list_empty(&(map->vmm_list))){
            dbg(DBG_PRINT,"(GRADING3B 1), vmarea list is empty, No mappings in the range\n");
	    return 1;
	} else {
            dbg(DBG_PRINT,"(GRADING3B 1), vmarea list is non-empty, checking the range empty\n");
	    vmarea_t *myarea;
	    list_iterate_begin(&(map->vmm_list),myarea,vmarea_t,vma_plink){
	        if (!((myarea->vma_start >= endvfn) || (myarea->vma_end <= startvfn))){
                    dbg(DBG_PRINT,"(GRADING3B), Overlap found, range not empty\n");
     		    return 0;   
	        }
            } list_iterate_end();
            dbg(DBG_PRINT,"(GRADING3B 1), No mappings in the range\n");
            return 1;
        }
}

/* Read into 'buf' from the virtual address space of 'map' starting at
 * 'vaddr' for size 'count'. To do so, you will want to find the vmareas
 * to read from, then find the pframes within those vmareas corresponding
 * to the virtual addresses you want to read, and then read from the
 * physical memory that pframe points to. You should not check permissions
 * of the areas. Assume (KASSERT) that all the areas you are accessing exist.
 * Returns 0 on success, -errno on error.
 */
int
vmmap_read(vmmap_t *map, const void *vaddr, void *buf, size_t count)
{
        /*NOT_YET_IMPLEMENTED("VM: vmmap_read");
        return 0;*/

                dbg(DBG_PRINT,"(GRADING3B 1), Maps are available to read\n");
		uint32_t vpageno = ADDR_TO_PN(vaddr), vpageoff = PAGE_OFFSET(vaddr);
                uint32_t phypageno;
		char *dest = (char*) buf;
		uint32_t vir_addr = (uint32_t)vaddr;
		vmarea_t *myarea;
		pframe_t *phy_page;
		char *source = NULL;
		int rem_count=0;
		while(count > 0) {
                        dbg(DBG_PRINT,"(GRADING3B 1), Reading the mapping info of size count\n");
			vpageno = ADDR_TO_PN(vir_addr);
			vpageoff = PAGE_OFFSET(vir_addr);
			myarea = vmmap_lookup(map, vpageno);
			phypageno = myarea->vma_off + vpageno - myarea->vma_start;
			pframe_lookup(myarea->vma_obj, phypageno, 0 , &phy_page);
			source = (char *)phy_page->pf_addr + vpageoff;
			rem_count = MIN(PAGE_SIZE - vpageoff, count);
			memcpy(dest, source, rem_count);
			count = count - rem_count;
			dest = dest + rem_count;
			vir_addr = vir_addr + rem_count;
		}
                dbg(DBG_PRINT,"(GRADING3B 1), Reading the mapping is done\n");
		return 0;

}

/* Write from 'buf' into the virtual address space of 'map' starting at
 * 'vaddr' for size 'count'. To do this, you will need to find the correct
 * vmareas to write into, then find the correct pframes within those vmareas,
 * and finally write into the physical addresses that those pframes correspond
 * to. You should not check permissions of the areas you use. Assume (KASSERT)
 * that all the areas you are accessing exist. Remember to dirty pages!
 * Returns 0 on success, -errno on error.
 */
int
vmmap_write(vmmap_t *map, void *vaddr, const void *buf, size_t count)
{
        /*NOT_YET_IMPLEMENTED("VM: vmmap_write");
        return 0;*/

                dbg(DBG_PRINT,"(GRADING3B 1), Maps are available to write\n");
		uint32_t vpageno, vpageoff, phypageno;
		char *dest = (char*) buf;
		uint32_t vir_addr = (uint32_t)vaddr;
		vmarea_t *myarea;
		pframe_t *phy_page;
		char *source = NULL;
		size_t rem_count=0;
	
		/*while(count > 0){*/
                dbg(DBG_PRINT,"(GRADING3B 1), Writing the mapping info of size count\n");
			vpageno = ADDR_TO_PN(vir_addr);
			vpageoff = PAGE_OFFSET(vir_addr);
			myarea = vmmap_lookup(map, vpageno);
			phypageno = myarea->vma_off + vpageno - myarea->vma_start;
			pframe_lookup(myarea->vma_obj, phypageno, 0 , &phy_page);
			source = (char *)phy_page->pf_addr + vpageoff;
			rem_count = MIN(PAGE_SIZE - vpageoff, count);
			memcpy(source, dest, rem_count);
			pframe_dirty(phy_page);
			/*count = count - rem_count;
			dest = dest + rem_count;
			vir_addr = vir_addr + rem_count;
		}*/
                dbg(DBG_PRINT,"(GRADING3B 1), Writing is done\n");
		return 0;

}
