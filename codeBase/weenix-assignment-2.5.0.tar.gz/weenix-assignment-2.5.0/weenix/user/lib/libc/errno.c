#include <errno.h>

int _libc_errno;
